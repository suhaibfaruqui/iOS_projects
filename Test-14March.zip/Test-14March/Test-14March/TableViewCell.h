//
//  TableViewCell.h
//  Test-14March
//
//  Created by User on 3/14/16.
//  Copyright © 2016 Suhaib. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *mobileLabel;
@end
