//
//  ViewController.m
//  Test-14March
//
//  Created by User on 3/14/16.
//  Copyright © 2016 Suhaib. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import "TableViewCell.h"


@interface ViewController ()
@property (nonatomic) NSMutableArray *devices;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.table.delegate = self;
    self.table.dataSource = self;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSManagedObjectContext *)managedObjectContext {
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // returns the number of entries
    return self.devices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell
    //set name and mobile textfield from data from 'device' array
    NSManagedObject *device = [self.devices objectAtIndex:indexPath.row];
    [cell.nameLabel setText:[device valueForKey:@"name"]];
    [cell.mobileLabel setText:[device valueForKey:@"mobile"]];
    
    return cell;
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    // Fetch the devices from persistent data store
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Device"];
    NSSortDescriptor* sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"name" ascending:YES];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];

    // store the data in devices array
    self.devices = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    //reload table
    [self.table reloadData];
}


- (IBAction)addButton:(id)sender {
    NSManagedObjectContext *context = [self managedObjectContext];
    
    //remove white spaces from start and end
    self.nameTextfield.text = [self.nameTextfield.text stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]];
    self.mobileTextfield.text = [self.mobileTextfield.text stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]];
    BOOL valid;
    NSCharacterSet *alphaNums = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *inStringSet = [NSCharacterSet characterSetWithCharactersInString:self.mobileTextfield.text];
    valid = [alphaNums isSupersetOfSet:inStringSet];
    
    if (![self.nameTextfield.text isEqualToString:@""] && ![self.mobileTextfield.text isEqualToString:@""] && valid)
    {
        NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Device" inManagedObjectContext:context];
        [newDevice setValue:self.nameTextfield.text forKey:@"name"];
        [newDevice setValue:self.mobileTextfield.text forKey:@"mobile"];
        
        NSError *error = nil;
        // Save the object to persistent store
        if (![context save:&error]) {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }
        
        [self dismissViewControllerAnimated:YES completion:nil];
        
        //load the view after adding records
        [self viewDidAppear:YES];
        
        //clear the textfields
        self.nameTextfield.text = @"";
        self.mobileTextfield.text = @"";
        
    }
    
    else
    
    {
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Please enter valid Name and Mobile number"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        
        [myAlertView show];
    }

   
}

- (IBAction)orderNameButton:(id)sender {
    [self viewDidAppear:YES];
}

- (IBAction)orderMobileButton:(id)sender {
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Device"];
    NSSortDescriptor* sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"mobile" ascending:YES];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    self.devices = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    NSLog(@"%@", self.devices);
    
    [self.table reloadData];

}


-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
        NSManagedObject *aManagedObject = [self.devices objectAtIndex:indexPath.row];
        [managedObjectContext deleteObject:aManagedObject];
        NSError *error;
        if (![managedObjectContext save:&error]) {
            // Handle the error.
        }
        
    }
    [self viewDidAppear:YES];
    
}

@end
