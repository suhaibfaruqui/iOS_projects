//
//  TableViewCell.m
//  Test-14March
//
//  Created by User on 3/14/16.
//  Copyright © 2016 Suhaib. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
