//
//  ViewController.h
//  Test-14March
//
//  Created by User on 3/14/16.
//  Copyright © 2016 Suhaib. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITextField *nameTextfield;
@property (weak, nonatomic) IBOutlet UITextField *mobileTextfield;
- (IBAction)addButton:(id)sender;
- (IBAction)orderNameButton:(id)sender;
- (IBAction)orderMobileButton:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *table;

@end

